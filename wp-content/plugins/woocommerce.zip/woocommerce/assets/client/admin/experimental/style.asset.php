<?php return array('version' => '78fc0c5d77a14a820fd1');
