<?php return array('dependencies' => array('wc-components', 'wc-store-data', 'wc-tracks', 'wp-element', 'wp-i18n'), 'version' => 'b269c64f9ca03088ccea');
