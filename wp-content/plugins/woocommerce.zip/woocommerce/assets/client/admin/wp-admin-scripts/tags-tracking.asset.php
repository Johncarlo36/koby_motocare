<?php return array('dependencies' => array('wc-tracks'), 'version' => '70833289b49d9f915a0b');
