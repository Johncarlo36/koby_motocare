<?php return array('dependencies' => array('wc-components', 'wc-currency', 'wc-number', 'wp-element', 'wp-html-entities'), 'version' => '170bbba6d8d25bd13f17');
