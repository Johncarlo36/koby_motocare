<?php return array('dependencies' => array('wc-tracks'), 'version' => '37002c2ae9a05a489019');
