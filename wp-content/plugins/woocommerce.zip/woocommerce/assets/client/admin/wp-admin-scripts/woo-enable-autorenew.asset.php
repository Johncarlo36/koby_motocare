<?php return array('dependencies' => array('wc-tracks', 'wp-dom-ready'), 'version' => '51341503d6ea36e07740');
