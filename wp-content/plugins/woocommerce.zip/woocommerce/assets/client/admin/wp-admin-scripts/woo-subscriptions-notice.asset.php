<?php return array('dependencies' => array('wc-tracks'), 'version' => '4d7996cc55f75ed796e7');
