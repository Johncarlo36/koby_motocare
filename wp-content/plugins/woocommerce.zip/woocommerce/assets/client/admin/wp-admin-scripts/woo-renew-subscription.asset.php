<?php return array('dependencies' => array('wc-tracks', 'wp-dom-ready'), 'version' => 'b1c03913b05a3e455e30');
