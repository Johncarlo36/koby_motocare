<?php return array('dependencies' => array('wc-customer-effort-score', 'wc-tracks'), 'version' => '675c493b9de1e90d2614');
