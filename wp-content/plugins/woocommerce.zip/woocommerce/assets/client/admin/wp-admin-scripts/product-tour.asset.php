<?php return array('dependencies' => array('wc-components', 'wc-tracks', 'wp-element', 'wp-hooks', 'wp-i18n'), 'version' => '72dd4935471da1ef3cce');
