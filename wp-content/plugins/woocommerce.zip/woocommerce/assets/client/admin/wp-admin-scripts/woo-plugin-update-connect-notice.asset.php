<?php return array('dependencies' => array('wc-tracks', 'wp-dom-ready'), 'version' => '53117109b6e1e8d466a3');
